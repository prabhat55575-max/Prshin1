package com.prsain.app.ui
import android.bluetooth.*; import android.content.*; import android.os.Bundle; import android.view.*; import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts; import androidx.appcompat.app.AppCompatActivity
import com.prsain.app.R; import com.prsain.app.bt.*; import com.prsain.app.data.*
class MainActivity:AppCompatActivity(),BluetoothChatService.Listener{
 lateinit var acct:AccountStore; lateinit var msgs:MessageStore
 var adapter:BluetoothAdapter?=null; var svc:BluetoothChatService?=null
 var peer:BluetoothDevice?=null; var peerName=""; val chat=mutableListOf<Msg>()
 lateinit var statusTv:TextView; lateinit var listLv:ListView; lateinit var inputEt:EditText; lateinit var chatAdapter:ArrayAdapter<String>
 val found=mutableListOf<BluetoothDevice>(); lateinit var foundAdapter:ArrayAdapter<String>
 lateinit var recv:BroadcastReceiver
 val permReq=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()){}
 val btOn=registerForActivityResult(ActivityResultContracts.StartActivityForResult()){}
 override fun onCreate(b:Bundle?){super.onCreate(b); acct=AccountStore(this); msgs=MessageStore(this)
  adapter=BluetoothAdapter.getDefaultAdapter(); if(adapter!=null)svc=BluetoothChatService(adapter!!).also{it.listeners.add(this)}
  buildUI(); checkPerms(); svc?.startServer()}
 fun buildUI(){ val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  statusTv=TextView(this).apply{text=getString(R.string.disconnected);setPadding(24,24,24,24)}
  val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  val bChat=Button(this).apply{text=getString(R.string.chat)}; val bNear=Button(this).apply{text=getString(R.string.nearby)}; val bSet=Button(this).apply{text=getString(R.string.settings)}
  val pager=FrameLayout(this).apply{id=View.generateViewId()}; val chatV=chatView(); val nearV=nearbyView(); val setV=settingsView()
  fun show(v:View){pager.removeAllViews();pager.addView(v)}
  bChat.setOnClickListener{show(chatV)}; bNear.setOnClickListener{show(nearV)}; bSet.setOnClickListener{show(setV)}
  tabs.addView(bChat);tabs.addView(bNear);tabs.addView(bSet); root.addView(statusTv);root.addView(tabs)
  root.addView(pager,LinearLayout.LayoutParams(-1,-1)); show(chatV); setContentView(root)}
 fun chatView():View{ val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  listLv=ListView(this); chatAdapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,mutableListOf()); listLv.adapter=chatAdapter
  val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
  inputEt=EditText(this).apply{hint=getString(R.string.type_message);layoutParams=LinearLayout.LayoutParams(0,-2,1f)}
  val send=Button(this).apply{text=getString(R.string.send)}; val clear=Button(this).apply{text=getString(R.string.clear_chat)}
  send.setOnClickListener{ val t=inputEt.text.toString(); if(t.isEmpty()||svc?.state!="Connected"){Toast.makeText(this,R.string.not_connected,Toast.LENGTH_SHORT).show();return@setOnClickListener}
   if(svc!!.send(t)){chat.add(Msg(t,true,System.currentTimeMillis()));msgs.save(peerName.ifEmpty{"peer"},chat);refreshChat();inputEt.setText("")} }
  clear.setOnClickListener{chat.clear();msgs.clear(peerName.ifEmpty{"peer"});refreshChat()}
  row.addView(inputEt);row.addView(send); l.addView(listLv,LinearLayout.LayoutParams(-1,0,1f)); l.addView(row); l.addView(clear); return l}
 fun nearbyView():View{ val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val scan=Button(this).apply{text=getString(R.string.scan)}; val lv=ListView(this)
  foundAdapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,mutableListOf()); lv.adapter=foundAdapter
  scan.setOnClickListener{ if(adapter?.isEnabled!=true){btOn.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return@setOnClickListener}
   found.clear();foundAdapter.clear(); BtHelper.startDiscovery(adapter!!); try{adapter!!.setName("Prsain-"+acct.display())}catch(_:Exception){} }
  lv.setOnItemClickListener{_,_,pos,_ -> val d=found[pos]
   androidx.appcompat.app.AlertDialog.Builder(this).setTitle(getString(R.string.connect_to,d.name?:"?"))
    .setMessage(getString(R.string.confirm_connect)).setPositiveButton(android.R.string.ok){_,_->peer=d;peerName=d.address;chat.clear();chat.addAll(msgs.load(peerName));refreshChat();svc?.connect(d)}.setNegativeButton(android.R.string.cancel,null).show() }
  val disc=Button(this).apply{text=getString(R.string.disconnect)}; disc.setOnClickListener{svc?.disconnect();svc?.startServer()}
  recv=BtHelper.receiver({d-> if(!found.any{it.address==d.address}){found.add(d);try{foundAdapter.add((d.name?:"?")+" - "+d.address)}catch(_:Exception){}} },{ }); val f=IntentFilter().apply{addAction(BluetoothDevice.ACTION_FOUND);addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)}; registerReceiver(recv,f)
  l.addView(scan);l.addView(lv,LinearLayout.LayoutParams(-1,0,1f));l.addView(disc); return l}
 fun settingsView():ScrollView{ val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
  fun add(t:String,fn:()->Unit){val b=Button(this).apply{text=t};b.setOnClickListener{fn()};l.addView(b)}
  add(getString(R.string.my_profile)){Toast.makeText(this,acct.display()+" ("+acct.username()+")",Toast.LENGTH_LONG).show()}
  add(getString(R.string.change_pin)){ val e=EditText(this).apply{hint="old,new"}; androidx.appcompat.app.AlertDialog.Builder(this).setTitle(getString(R.string.change_pin)).setView(e).setPositiveButton(android.R.string.ok){_,_->val p=e.text.toString().split(",");if(p.size==2&&acct.changePin(p[0].trim(),p[1].trim()))Toast.makeText(this,"OK",Toast.LENGTH_SHORT).show() else Toast.makeText(this,R.string.pin_error,Toast.LENGTH_SHORT).show()}.show()}
  add(getString(R.string.dark_mode)){}
  add(getString(R.string.bluetooth_settings)){startActivity(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))}
  add(getString(R.string.clear_history)){msgs.clearAll();chat.clear();refreshChat()}
  add(getString(R.string.about)){Toast.makeText(this,"Prsain — "+getString(R.string.tagline),Toast.LENGTH_LONG).show()}
  val s=ScrollView(this);s.addView(l);return s}
 fun checkPerms(){ val m=BtHelper.missing(this); if(m.isNotEmpty()){ val r=m.joinToString("\n"){BtHelper.rationale(it)}; androidx.appcompat.app.AlertDialog.Builder(this).setTitle("Permissions").setMessage(r).setPositiveButton(android.R.string.ok){_,_->permReq.launch(m.toTypedArray())}.show() } }
 fun refreshChat(){ val items=chat.map{(if(it.mine)"Me: " else peerName+": ")+it.text}; chatAdapter.clear();chatAdapter.addAll(items)}
 override fun onState(s:String){runOnUiThread{statusTv.text=s}}
 override fun onMessage(text:String){runOnUiThread{chat.add(Msg(text,false,System.currentTimeMillis()));msgs.save(peerName.ifEmpty{"peer"},chat);refreshChat()}}
 override fun onDeviceConnected(d:BluetoothDevice){peer=d;peerName=d.address;runOnUiThread{chat.clear();chat.addAll(msgs.load(peerName));refreshChat();Toast.makeText(this,getString(R.string.connected),Toast.LENGTH_SHORT).show()}}
 override fun onDeviceDisconnected(){runOnUiThread{Toast.makeText(this,R.string.disconnected,Toast.LENGTH_SHORT).show()}}
 override fun onDestroy(){try{unregisterReceiver(recv)}catch(_:Exception){};svc?.disconnect();super.onDestroy()}
}

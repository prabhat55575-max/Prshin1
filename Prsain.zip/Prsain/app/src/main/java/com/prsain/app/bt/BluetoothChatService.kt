package com.prsain.app.bt
import android.annotation.SuppressLint
import android.bluetooth.*
import java.io.*
import java.util.*
import java.util.concurrent.CopyOnWriteArrayList
@SuppressLint("MissingPermission")
class BluetoothChatService(private val adapter:BluetoothAdapter){
 interface Listener{ fun onState(s:String); fun onMessage(text:String); fun onDeviceConnected(d:BluetoothDevice); fun onDeviceDisconnected() }
 val listeners=CopyOnWriteArrayList<Listener>()
 @Volatile var state="Disconnected"; private set
 var socket:BluetoothSocket?=null; private var acceptT:Thread?=null; private var connT:Thread?=null; private var ioT:Thread?=null
 companion object{ val APP_UUID:UUID=UUID.fromString("a1b2c3d4-e5f6-47a8-9b0c-d1e2f3a4b5c6"); const val NAME="Prsain" }
 private fun set(s:String){state=s;listeners.forEach{it.onState(s)}}
 fun startServer(){ if(acceptT?.isAlive==true)return; set("Searching"); acceptT=Thread{ try{ val ss=adapter.listenUsingRfcommWithServiceRecord(NAME,APP_UUID); val s=ss.accept(); ss.close(); onConnected(s) }catch(e:Exception){ set("Disconnected") } }; acceptT?.start() }
 fun connect(d:BluetoothDevice){ connT?.interrupt(); set("Connecting"); connT=Thread{ try{ adapter.cancelDiscovery(); val s=d.createRfcommSocketToServiceRecord(APP_UUID); s.connect(); onConnected(s) }catch(e:Exception){ set("Disconnected") } }; connT?.start() }
 private fun onConnected(s:BluetoothSocket){ socket=s; set("Connected"); try{listeners.forEach{it.onDeviceConnected(s.remoteDevice)}}catch(_:Exception){}; ioT=Thread{ val inp=s.inputStream; val buf=ByteArray(4096); val acc=ByteArrayOutputStream(); try{ while(true){ val n=inp.read(buf); if(n<0)break; var st=0; for(i in 0 until n){ if(buf[i]==0x0A.toByte()){ val line=acc.toString("UTF-8"); acc.reset(); if(line.isNotEmpty())listeners.forEach{it.onMessage(line)}; st=i+1 } }; if(st<n)acc.write(buf,st,n-st) } }catch(_:Exception){}; disconnect() }; ioT?.start() }
 fun send(text:String):Boolean{ return try{ val o=socket?.outputStream?:return false; o.write((text+"\n").toByteArray(Charsets.UTF_8)); o.flush(); true }catch(_:Exception){ false } }
 fun disconnect(){ try{socket?.close()}catch(_:Exception){}; socket=null; set("Disconnected"); listeners.forEach{it.onDeviceDisconnected()} }
}

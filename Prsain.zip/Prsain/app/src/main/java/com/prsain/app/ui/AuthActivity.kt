package com.prsain.app.ui
import android.content.Intent; import android.os.Bundle; import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.prsain.app.data.AccountStore
class AuthActivity:AppCompatActivity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val s=AccountStore(this); if(s.hasAccount()){askPin(s);return}
  val lay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(48,48,48,48)}
  val t1=EditText(this).apply{hint=getString(R.string.username)}; val t2=EditText(this).apply{hint=getString(R.string.display_name)}
  val t3=EditText(this).apply{hint=getString(R.string.pin)}; val btn=Button(this).apply{text=getString(R.string.create_account)}
  btn.setOnClickListener{ val u=t1.text.toString().trim();val d=t2.text.toString().trim();val p=t3.text.toString().trim()
   if(u.isEmpty()||d.isEmpty()||p.length !in 4..6||!p.all{it.isDigit()}){Toast.makeText(this,R.string.pin_error,Toast.LENGTH_LONG).show();return@setOnClickListener}
   s.create(u,d,p,null); go() }
  lay.addView(TextView(this).apply{text="Prsain";textSize=32f}); lay.addView(TextView(this).apply{text=getString(R.string.tagline)})
  lay.addView(t1);lay.addView(t2);lay.addView(t3);lay.addView(btn); setContentView(lay)}
 private fun askPin(s:AccountStore){ val lay=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(48,48,48,48)}
  val t=EditText(this).apply{hint=getString(R.string.pin)}; val b=Button(this).apply{text=getString(R.string.login)}
  b.setOnClickListener{if(s.verify(t.text.toString().trim()))go() else Toast.makeText(this,R.string.pin_error,Toast.LENGTH_SHORT).show()}
  lay.addView(TextView(this).apply{text="Prsain";textSize=32f});lay.addView(t);lay.addView(b);setContentView(lay)}
 private fun go(){startActivity(Intent(this,MainActivity::class.java));finish()}
}

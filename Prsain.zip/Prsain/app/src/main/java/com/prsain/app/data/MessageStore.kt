package com.prsain.app.data
import android.content.Context
import org.json.JSONArray; import org.json.JSONObject
data class Msg(val text:String,val mine:Boolean,val ts:Long)
class MessageStore(ctx:Context){
 private val p=ctx.getSharedPreferences("prsain_msgs",Context.MODE_PRIVATE)
 fun load(peer:String):MutableList<Msg>{val l=mutableListOf<Msg>();val a=JSONArray(p.getString(k(peer),"[]"));for(i in 0 until a.length()){val o=a.getJSONObject(i);l.add(Msg(o.getString("t"),o.getBoolean("m"),o.getLong("ts")))};return l}
 fun save(peer:String,list:List<Msg>){val a=JSONArray();list.forEach{val o=JSONObject();o.put("t",it.text);o.put("m",it.mine);o.put("ts",it.ts);a.put(o)};p.edit().putString(k(peer),a.toString()).apply()}
 fun clear(peer:String){p.edit().remove(k(peer)).apply()}
 fun clearAll(){p.edit().clear().apply()}
 private fun k(peer:String)="chat_"+peer.hashCode()
}

package com.prsain.app.bt
import android.Manifest; import android.bluetooth.BluetoothAdapter; import android.bluetooth.BluetoothDevice
import android.content.*; import android.content.pm.PackageManager; import android.os.Build
import androidx.core.content.ContextCompat
object BtHelper{
 fun neededPermissions():Array<String>{ val l=mutableListOf<String>(); if(Build.VERSION.SDK_INT>=31){l.add(Manifest.permission.BLUETOOTH_SCAN);l.add(Manifest.permission.BLUETOOTH_CONNECT);l.add(Manifest.permission.BLUETOOTH_ADVERTISE)} else {l.add(Manifest.permission.ACCESS_FINE_LOCATION)}; return l.toTypedArray() }
 fun missing(ctx:Context)=neededPermissions().filter{ContextCompat.checkSelfPermission(ctx,it)!=PackageManager.PERMISSION_GRANTED}
 fun rationale(p:String)=when(p){ Manifest.permission.BLUETOOTH_SCAN->"Scan finds nearby Prsain users."; Manifest.permission.BLUETOOTH_CONNECT->"Connect pairs and chats with the chosen device."; Manifest.permission.BLUETOOTH_ADVERTISE->"Advertise makes your phone visible to nearby Prsain users."; else->"Location is needed for Bluetooth discovery on older Android." }
 fun startDiscovery(a:BluetoothAdapter):Boolean{ return try{ if(a.isDiscovering)a.cancelDiscovery(); a.startDiscovery() }catch(_:Exception){false} }
 fun receiver(onFound:(BluetoothDevice)->Unit,onDone:()->Unit)=object:BroadcastReceiver(){ override fun onReceive(c:Context,i:Intent){ when(i.action){ BluetoothDevice.ACTION_FOUND->{ val d:BluetoothDevice?=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE,BluetoothDevice::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE); d?.let(onFound) } BluetoothAdapter.ACTION_DISCOVERY_FINISHED->onDone() } } }
}

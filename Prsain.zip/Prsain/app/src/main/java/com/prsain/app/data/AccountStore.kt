package com.prsain.app.data
import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import com.prsain.app.util.Security
class AccountStore(ctx:Context){
 private val mk=MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
 private val p=EncryptedSharedPreferences.create(ctx,"prsain_acct",mk,EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM)
 fun hasAccount()=p.contains("pin_hash")
 fun create(username:String,display:String,pin:String,photo:String?){p.edit().putString("username",username).putString("display",display).putString("pin_hash",Security.sha256(pin)).putString("photo",photo).apply()}
 fun verify(pin:String)=p.getString("pin_hash","")==Security.sha256(pin)
 fun changePin(old:String,new:String):Boolean{if(!verify(old))return false;p.edit().putString("pin_hash",Security.sha256(new)).apply();return true}
 fun display()=p.getString("display","")?:""; fun username()=p.getString("username","")?:""
 fun clearAll(){p.edit().clear().apply()}
}

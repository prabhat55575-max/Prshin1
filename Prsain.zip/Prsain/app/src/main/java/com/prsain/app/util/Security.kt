package com.prsain.app.util
import java.security.MessageDigest
object Security { fun sha256(s:String):String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString(""){"%02x".format(it)} }

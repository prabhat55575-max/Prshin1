# Prsain — Chat Privately. Offline.

Offline phone-to-phone Bluetooth chat (RFCOMM). No internet/SIM/cloud.

## Build APK
1. Open in Android Studio (Hedgehog+).
2. Let Gradle sync.
3. Run on two physical devices (Bluetooth required; emulator cannot do BT).
4. Build > Build Bundle(s)/APK(s) > Build APK(s).

## Use
1. Create account (username, display name, 4-6 digit PIN, optional photo).
2. Nearby > enable Bluetooth > Scan.
3. One device taps Connect; other accepts the pairing/connection prompt.
4. Chat in real time. Messages persist locally.

## Tech
- Bluetooth Classic RFCOMM (UUID 00001101-0000-1000-8000-00805F9B34FB, app UUID `a1b2c3d4-...`).
- EncryptedSharedPreferences for account/PIN (SHA-256 hash, not plaintext).
- Local message store via SharedPreferences JSON (per peer).
- Runtime permissions: BLUETOOTH_SCAN/CONNECT/ADVERTISE (API 31+) with rationale; ACCESS_FINE_LOCATION on API 23-30 for discovery.
- Locales: English + Hindi (res/values-hi).
